# elasticsearch-5-shaded
Maven pom configuration for shading elasticsearch 5. Most problems were related to log4j2. Needed to replace some resources with updated class path. Also there was problem with manifest being checked for some properties at runtime.

Steps  :

1. mvn -DskipTests clean install
2. Add the dependency in metron pom.xml

        <dependency>
            <groupId>alphaserve.soc</groupId>
            <artifactId>es-v5-shade</artifactId>
            <version>5.2.2</version>
        </dependency>

        for below module pom.xml
        - metron-platform/elasticsearch-shaded
        - metron-platform/metron-elasticsearch
        - metron-platform/metron-data-management