package com.ast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

//http://www.thymeleaf.org/doc/articles/layouts.html
@EnableZuulProxy
@SpringBootApplication
public class AstSocAuthentication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(AstSocAuthentication.class, args);
	}

}