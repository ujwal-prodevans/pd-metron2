package com.ast.filter;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.net.MalformedURLException;
import java.net.URL;

@Component
public class AstRouteFilter extends ZuulFilter {
	private static Logger log = LoggerFactory.getLogger(AstRouteFilter.class);
	private static String USERNAME = "username";
	private static String PASSWORD = "password";

	@Override
	public String filterType() {
		return "route";
	}

	@Override
	public int filterOrder() {
		return 1;
	}

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() {

		RequestContext ctx = RequestContext.getCurrentContext();
		HttpServletRequest request = ctx.getRequest();
		String username = null;
		String password = null;
		try {
			String cookies = request.getHeader("Cookie");
			String[] cookieMap = cookies.split(";");
			String user = getParam("socuser",cookieMap);

			if(!StringUtils.isEmpty(user)){
				ctx.addZuulRequestHeader("soc-user",user);
			}else{
				ctx.setRouteHost(new URL("http://10.244.30.207:8008"));
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			try {
				ctx.setRouteHost(new URL("http://10.244.30.207:8008"));
			} catch (MalformedURLException e1) {
				e1.printStackTrace();
			}
		}
		log.info("AstRouteFilter: " + String.format("%s request to %s", request.getMethod(), request.getRequestURL().toString()));
		
		return null;
	}

	public String getParam(String param,String[] params){
		try {
			for (String p : params) {
				if (!StringUtils.isEmpty(p) && p.contains(param)) {
					return p.substring(p.indexOf(param + "=") + param.length() + 1);
				}
			}
		}catch (Exception e){
			log.error(e.getMessage());
			return null;
		}
		return null;
	}

}