package com.ast.authentication;


import com.sun.jndi.ldap.LdapCtxFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class AstAuthenticationProvider implements AuthenticationProvider {
    private static Logger logger = LoggerFactory.getLogger(AstAuthenticationProvider.class);
	final String ldapAdServer = "ldap://10.244.30.60:389";
	final String simpleSecurityAuthentication = "Simple";
	final String initialContextFactory = "com.sun.jndi.ldap.LdapCtxFactory";
	final String domainName = "exenet.com";
	Hashtable props = null;
	Hashtable<String, Object> env = new Hashtable<String, Object>();
	
	public AstAuthenticationProvider() {

    	env.put(Context.SECURITY_AUTHENTICATION, simpleSecurityAuthentication);
    	env.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);
        env.put(Context.PROVIDER_URL, ldapAdServer);
        env.put("java.naming.ldap.attributes.binary", "objectSID");
        
        }
	
	@Override
    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
    	
        String name = authentication.getName();
        String password = authentication.getCredentials().toString();
        
    	DirContext context;
       
        props = new Hashtable();
        String principalName = name + "@" + "exenet.com";
        props.put(Context.SECURITY_PRINCIPAL, principalName);
        props.put(Context.SECURITY_CREDENTIALS, password);
    	
        try {
            context = LdapCtxFactory.getLdapCtxInstance(ldapAdServer+'/', props);
            logger.debug("Authentication succeeful for user" +  principalName);
            List<GrantedAuthority> grantedAuths = new ArrayList<GrantedAuthority>();
            grantedAuths.add(new SimpleGrantedAuthority("ROLE_DUMMY"));
            grantedAuths.add(new SimpleGrantedAuthority("ROLE_DUMMY2"));
            return new UsernamePasswordAuthenticationToken(
                    name, password, grantedAuths);

           
        } catch(Exception e) {
            logger.error("Authentication Failed"+e.getCause()+":"+e.getMessage());
            return null;
        }

    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(
                UsernamePasswordAuthenticationToken.class);
    }
}